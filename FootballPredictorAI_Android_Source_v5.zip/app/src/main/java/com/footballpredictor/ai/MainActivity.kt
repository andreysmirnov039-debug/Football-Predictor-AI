package com.footballpredictor.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.widget.*
import kotlin.math.exp
import kotlin.math.pow

class MainActivity : Activity() {
    private val teams = listOf("Команда А", "Команда Б", "Команда В", "Команда Г", "Команда Д")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(0xFF101827.toInt())
        }
        scroll.addView(page)
        setContentView(scroll)

        fun label(value: String, size: Float = 16f, bold: Boolean = false) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(0xFFF4F7FB.toInt())
                if (bold) setTypeface(null, Typeface.BOLD)
                setPadding(0, 12, 0, 8)
            }

        page.addView(label("⚽ Football Predictor AI 5.0", 25f, true))
        page.addView(label("Poisson + Elo • Android", 16f))
        page.addView(label("Виртуальный режим • бюджет: 1 000 ₽", 14f))
        page.addView(label("Демо: для реальных оценок нужна проверенная история матчей.", 13f))

        val home = Spinner(this)
        val away = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, teams)
        home.adapter = adapter
        away.adapter = adapter
        away.setSelection(1)
        page.addView(label("Хозяева"))
        page.addView(home)
        page.addView(label("Гости"))
        page.addView(away)

        val result = label("Выбери команды и нажми кнопку.", 16f)
        page.addView(Button(this).apply {
            text = "Рассчитать прогноз"
            setOnClickListener {
                val h = home.selectedItem.toString()
                val a = away.selectedItem.toString()
                if (h == a) {
                    result.text = "Выбери две разные команды."
                } else {
                    val seed = kotlin.math.abs((h.hashCode().toLong() * 31L + a.hashCode()).toInt())
                    val lh = 1.15 + (seed % 60) / 100.0
                    val la = 0.85 + ((seed / 7) % 55) / 100.0
                    val probs = Array(7) { i -> DoubleArray(7) { j -> poisson(i, lh) * poisson(j, la) } }
                    var ph = 0.0; var pd = 0.0; var pa = 0.0
                    for (i in 0..6) for (j in 0..6) {
                        when { i > j -> ph += probs[i][j]; i == j -> pd += probs[i][j]; else -> pa += probs[i][j] }
                    }
                    val score = (0..6).flatMap { i -> (0..6).map { j -> Triple(i, j, probs[i][j]) } }.maxBy { it.third }
                    result.text = "Прогноз: $h — $a\n" +
                        "Победа хозяев: ${percent(ph)}\nНичья: ${percent(pd)}\nПобеда гостей: ${percent(pa)}\n" +
                        "Ожидаемые голы: ${"%.2f".format(lh)} : ${"%.2f".format(la)}\n" +
                        "Вероятный счёт: ${score.first}:${score.second}\n\n" +
                        "Демонстрационный расчёт на условных параметрах, не прогноз реального матча."
                }
            }
        })
        page.addView(result)
    }

    private fun poisson(k: Int, lambda: Double): Double {
        var f = 1.0
        for (i in 2..k) f *= i
        return exp(-lambda) * lambda.pow(k) / f
    }
    private fun percent(v: Double) = "${"%.1f".format(v * 100)}%"
}
