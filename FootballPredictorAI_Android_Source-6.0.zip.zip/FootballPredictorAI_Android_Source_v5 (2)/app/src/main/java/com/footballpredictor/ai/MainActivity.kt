package com.footballpredictor.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.util.Locale
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow

private const val SERVER =
"https://football-predictor-ai-server-2026.chabangodyel18.workers.dev"

data class Competition(val name: String, val code: String) {
override fun toString() = name
}

data class Game(
val home: String,
val away: String,
val date: String,
val homeGoals: Int?,
val awayGoals: Int?
)

class MainActivity : Activity() {

private lateinit var page: LinearLayout  
private lateinit var leagues: Spinner  
private lateinit var matches: Spinner  
private lateinit var info: TextView  
private lateinit var result: TextView  
private lateinit var loadButton: Button  
private lateinit var predictButton: Button  

private var competitions = listOf<Competition>()  
private var games = listOf<Game>()  
private var history = listOf<Game>()  

override fun onCreate(savedInstanceState: Bundle?) {  
    super.onCreate(savedInstanceState)  

    val scroll = ScrollView(this)  

    page = LinearLayout(this).apply {  
        orientation = LinearLayout.VERTICAL  
        setPadding(28, 32, 28, 28)  
        setBackgroundColor(0xFF101827.toInt())  
    }  

    scroll.addView(page)  
    setContentView(scroll)  

    page.addView(label("⚽ Football Predictor AI 6.0", 25f, true))  
    page.addView(label("Poisson + Elo • реальные данные", 16f))  
    page.addView(label("Виртуальный бюджет: 1 000 ₽", 14f))  

    page.addView(label("Выбери лигу", 17f, true))  

    leagues = Spinner(this)  
    page.addView(leagues)  

    loadButton = Button(this).apply {  
        text = "Загрузить матчи"  
        setOnClickListener { loadMatches() }  
    }  
    page.addView(loadButton)  

    page.addView(label("Выбери матч", 17f, true))  

    matches = Spinner(this)  
    page.addView(matches)  

    predictButton = Button(this).apply {  
        text = "Рассчитать прогноз"  
        setOnClickListener { calculateForecast() }  
    }  
    page.addView(predictButton)  

    info = label("Подключение к серверу...", 14f)  
    page.addView(info)  

    result = label("", 16f)  
    page.addView(result)  

    loadButton.isEnabled = false  
    predictButton.isEnabled = false  

    loadCompetitions()  
}  

private fun label(  
    value: String,  
    size: Float = 16f,  
    bold: Boolean = false  
): TextView {  
    return TextView(this).apply {  
        text = value  
        textSize = size  
        setTextColor(0xFFF4F7FB.toInt())  
        if (bold) setTypeface(null, Typeface.BOLD)  
        setPadding(0, 12, 0, 8)  
    }  
}  

private fun request(path: String): JSONObject {  
    val connection =  
        URL("$SERVER$path").openConnection() as HttpURLConnection  

    connection.requestMethod = "GET"  
    connection.connectTimeout = 15000  
    connection.readTimeout = 20000  

    try {  
        val code = connection.responseCode  
        val stream = if (code in 200..299) {  
            connection.inputStream  
        } else {  
            connection.errorStream  
        }  

        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""  

        if (code !in 200..299) {  
            throw Exception("Ошибка сервера $code: $body")  
        }  

        return JSONObject(body)  
    } finally {  
        connection.disconnect()  
    }  
}  

private fun loadCompetitions() {  
    info.text = "Загружаю список лиг..."  

    Thread {  
        try {  
            val json = request("/competitions")  
            val array = json.getJSONArray("competitions")  
            val loaded = mutableListOf<Competition>()  

            for (i in 0 until array.length()) {  
                val item = array.getJSONObject(i)  
                val name = item.optString("name")  
                val code = item.optString("code")  

                if (name.isNotBlank() && code.isNotBlank()) {  
                    loaded.add(Competition(name, code))  
                }  
            }  

            runOnUiThread {  
                competitions = loaded  

                val adapter = ArrayAdapter(  
                    this,  
                    android.R.layout.simple_spinner_item,  
                    competitions  
                )  
                adapter.setDropDownViewResource(  
                    android.R.layout.simple_spinner_dropdown_item  
                )  

                leagues.adapter = adapter  
                loadButton.isEnabled = competitions.isNotEmpty()  

                info.text = if (competitions.isNotEmpty()) {  
                    "Доступно лиг: ${competitions.size}. Выбери лигу."  
                } else {  
                    "Список лиг пуст."  
                }  
            }  
        } catch (e: Exception) {  
            runOnUiThread {  
                info.text = "Ошибка загрузки лиг: ${e.message}"  
            }  
        }  
    }.start()  
}  

private fun loadMatches() {  
    val competition =  
        leagues.selectedItem as? Competition ?: return  

    loadButton.isEnabled = false  
    predictButton.isEnabled = false  
    result.text = ""  
    info.text = "Загружаю матчи..."  

    games = emptyList()  
    history = emptyList()  

    Thread {  
        try {  
            val today = LocalDate.now()  
            val from = today.toString()  
            val to = today.plusDays(14).toString()  

            val json = request(  
                "/matches?competitions=${competition.code}" +  
                    "&dateFrom=$from&dateTo=$to"  
            )  

            val array = json.optJSONArray("matches")  
            val loaded = mutableListOf<Game>()  

            if (array != null) {  
                for (i in 0 until array.length()) {  
                    val item = array.getJSONObject(i)  

                    val home = item.optJSONObject("homeTeam")  
                        ?.optString("name", "") ?: ""  

                    val away = item.optJSONObject("awayTeam")  
                        ?.optString("name", "") ?: ""  

                    if (home.isBlank() || away.isBlank()) continue  

                    loaded.add(  
                        Game(  
                            home,  
                            away,  
                            item.optString("utcDate"),  
                            null,  
                            null  
                        )  
                    )  
                }  
            }  

            runOnUiThread {  
                games = loaded  

                val names = games.map {  
                    "${it.home} — ${it.away} (${it.date.take(10)})"  
                }  

                val adapter = ArrayAdapter(  
                    this,  
                    android.R.layout.simple_spinner_item,  
                    names  
                )  
                adapter.setDropDownViewResource(  
                    android.R.layout.simple_spinner_dropdown_item  
                )  

                matches.adapter = adapter  
                loadButton.isEnabled = true  

                info.text = if (games.isNotEmpty()) {  
                    "Найдено матчей: ${games.size}. Загружаю историю..."  
                } else {  
                    "Матчей на ближайшие 14 дней не найдено."  
                }  
            }  

            loadHistory(competition.code)  
        } catch (e: Exception) {  
            runOnUiThread {  
                loadButton.isEnabled = true  
                info.text = "Ошибка загрузки матчей: ${e.message}"  
            }  
        }  
    }.start()  
}  

private fun loadHistory(code: String) {  
    Thread {  
        try {  
            val today = LocalDate.now()  
            val from = today.minusDays(30).toString()  
            val to = today.minusDays(1).toString()  

            val json = request(  
                "/matches?competitions=$code" +  
                    "&dateFrom=$from&dateTo=$to&status=FINISHED"  
            )  

            val array = json.optJSONArray("matches")  
            val loaded = mutableListOf<Game>()  

            if (array != null) {  
                for (i in 0 until array.length()) {  
                    val item = array.getJSONObject(i)  

                    val home = item.optJSONObject("homeTeam")  
                        ?.optString("name", "") ?: ""  

                    val away = item.optJSONObject("awayTeam")  
                        ?.optString("name", "") ?: ""  

                    val score = item.optJSONObject("score")  
                        ?.optJSONObject("fullTime")  

                    if (home.isBlank() || away.isBlank() ||  
                        score == null ||  
                        score.isNull("home") ||  
                        score.isNull("away")  
                    ) continue  

                    loaded.add(  
                        Game(  
                            home,  
                            away,  
                            item.optString("utcDate"),  
                            score.optInt("home"),  
                            score.optInt("away")  
                        )  
                    )  
                }  
            }  

            runOnUiThread {  
                history = loaded  
                predictButton.isEnabled = games.isNotEmpty()  

                info.text =  
                    "Матчей: ${games.size}. " +  
                    "Завершённых матчей для анализа: ${history.size}."  
            }  
        } catch (e: Exception) {  
            runOnUiThread {  
                history = emptyList()  
                predictButton.isEnabled = false  
                info.text =  
                    "Матчи загружены, но история недоступна: ${e.message}"  
            }  
        }  
    }.start()  
}  

private fun calculateForecast() {  
    if (games.isEmpty()) return  

    if (history.isEmpty()) {  
        result.text =  
            "Недостаточно исторических данных. " +  
            "Попробуй другую лигу или повтори позже."  
        return  
    }  

    val game = games.getOrNull(matches.selectedItemPosition) ?: return  

    result.text = forecast(game)  
}  

private fun forecast(game: Game): String {  
    val ratings = mutableMapOf<String, Double>()  

    history.forEach { match ->  
        val hg = match.homeGoals ?: return@forEach  
        val ag = match.awayGoals ?: return@forEach  

        val rh = ratings[match.home] ?: 1500.0  
        val ra = ratings[match.away] ?: 1500.0  

        val expected = 1.0 / (  
            1.0 + 10.0.pow(-((rh + 60.0 - ra) / 400.0))  
        )  

        val actual = when {  
            hg > ag -> 1.0  
            hg == ag -> 0.5  
            else -> 0.0  
        }  

        val change = 20.0 *  
            ln(1.0 + kotlin.math.abs(hg - ag)) *  
            (actual - expected)  

        ratings[match.home] = rh + change  
        ratings[match.away] = ra - change  
    }  

    fun recent(team: String) = history  
        .filter { it.home == team || it.away == team }  
        .takeLast(8)  

    fun scored(match: Game, team: String): Int =  
        if (match.home == team) match.homeGoals ?: 0  
        else match.awayGoals ?: 0  

    fun conceded(match: Game, team: String): Int =  
        if (match.home == team) match.awayGoals ?: 0  
        else match.homeGoals ?: 0  

    val homeGames = recent(game.home)  
    val awayGames = recent(game.away)  

    if (homeGames.isEmpty() || awayGames.isEmpty()) {  
        return "Недостаточно истории для одной из команд."  
    }  

    val leagueHome = history.mapNotNull { it.homeGoals }  
        .average().coerceAtLeast(0.2)  

    val leagueAway = history.mapNotNull { it.awayGoals }  
        .average().coerceAtLeast(0.2)  

    val hAttack = homeGames.map {  
        scored(it, game.home)  
    }.average().coerceAtLeast(0.1)  

    val hDefense = homeGames.map {  
        conceded(it, game.home)  
    }.average().coerceAtLeast(0.1)  

    val aAttack = awayGames.map {  
        scored(it, game.away)  
    }.average().coerceAtLeast(0.1)  

    val aDefense = awayGames.map {  
        conceded(it, game.away)  
    }.average().coerceAtLeast(0.1)  

    val hxg = (  
        leagueHome * (hAttack / leagueHome) *  
            (aDefense / leagueAway)  
    ).coerceIn(0.15, 4.5)  

    val axg = (  
        leagueAway * (aAttack / leagueAway) *  
            (hDefense / leagueHome)  
    ).coerceIn(0.15, 4.5)  

    fun poisson(k: Int, lambda: Double): Double {  
        var factorial = 1.0  
        for (i in 2..k) factorial *= i  
        return exp(-lambda) * lambda.pow(k) / factorial  
    }  

    var ph = 0.0  
    var pd = 0.0  
    var pa = 0.0  
    var best = 0.0  
    var bestScore = "0:0"  

    for (i in 0..10) {  
        for (j in 0..10) {  
            val p = poisson(i, hxg) * poisson(j, axg)  

            when {  
                i > j -> ph += p  
                i == j -> pd += p  
                else -> pa += p  
            }  

            if (p > best) {  
                best = p  
                bestScore = "$i:$j"  
            }  
        }  
    }  

    val eloDiff =  
        (ratings[game.home] ?: 1500.0) + 60.0 -  
        (ratings[game.away] ?: 1500.0)  

    val eloHome = 1.0 / (  
        1.0 + 10.0.pow(-eloDiff / 400.0)  
    )  

    val eloDraw = 0.25 *  
        (1.0 - kotlin.math.abs(2.0 * eloHome - 1.0))  

    val eHome = eloHome * (1.0 - eloDraw)  
    val eAway = (1.0 - eloHome) * (1.0 - eloDraw)  

    val pHome = 0.75 * ph + 0.25 * eHome  
    val pDraw = 0.75 * pd + 0.25 * eloDraw  
    val pAway = 0.75 * pa + 0.25 * eAway  

    val total = pHome + pDraw + pAway  

    fun percent(value: Double) =  
        String.format(Locale.US, "%.1f%%", value / total * 100.0)  

    return """  
        ПРОГНОЗ МАТЧА  

        ${game.home} — ${game.away}  

        Победа хозяев: ${percent(pHome)}  
        Ничья: ${percent(pDraw)}  
        Победа гостей: ${percent(pAway)}  

        Ожидаемые голы: ${  
            String.format(Locale.US, "%.2f", hxg)  
        } : ${  
            String.format(Locale.US, "%.2f", axg)  
        }  

        Наиболее вероятный счёт: $bestScore  

        Исторических матчей: ${history.size}  

        Это статистическая оценка, а не гарантия результата.  
    """.trimIndent()  
}

}